// Saved plugin settings (data.json). Your categories and labels live in the database instead, see data/Database.ts.
export interface FinanceSettings {
	dbFile: string;               // finance.db made by myFinances: full path, "~/..." or a path inside the vault
	devDbFile: string;            // dev-finance.db made by `make dev`, read only; '' = none
	currency: string;             // only rows in this currency are counted
	locale: string;               // number and month format, e.g. "en-GB"
	hiddenSections: string[];     // dashboard section ids not drawn
	sectionOrder: string[];       // dashboard section ids in page order, [] = default
	collapsedSections: string[];  // dashboard section ids showing only their title
	shownCounterparties: string[]; // counterparty names in "Spending by counterparty"
	subscriptionsOverall: boolean; // Subscriptions section: every payment (true) or up to the shown month
}
